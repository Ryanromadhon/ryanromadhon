{
    "name" : "Litebrain - Bengkel" , 
    "version" : "1.0.0", 
    "author": "Braintama", 
    "depends" : [
        "sale",
        "fleet",
        ],
    "description": """Custom Bengkel for Paramita Ban""", 
    "category" : "Management", 
    "auto_install" : False, 
    "application" : True, 
    'assets': {
        'web.assets_backend': [
        ],
        'web.assets_qweb': [
        ],
    },
    "data" : [
        'views/sale_order_views.xml',
        'views/fleet_vehicle_views.xml',
    ], 
    "license" :  "LGPL-3" , 
}
